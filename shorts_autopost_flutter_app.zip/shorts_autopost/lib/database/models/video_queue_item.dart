import '../../core/constants.dart';

/// Maps 1:1 to the `video_queue` SQLite table.
class VideoQueueItem {
  final String id; // uuid v4
  final String filePath;
  final String fileHash; // sha256 of file bytes — used for dedupe
  final String? aspectRatio; // e.g. "9:16", "16:9" — set after probing

  // YouTube fields
  final String? ytTitle;
  final String? ytDesc;
  final String? ytTags; // comma-separated

  // Instagram fields
  final String? igCaption;
  final String? igHashtags; // space-separated, includes #

  // Facebook fields
  final String? fbPostText;
  final String? fbTags;

  final String? coverFramePath;
  final QueueStatus status;
  final DateTime? scheduledAt;
  final DateTime? uploadedAt;
  final String? errorLog;

  // Published post URLs, filled in after each platform succeeds.
  final String? ytPostUrl;
  final String? igPostUrl;
  final String? fbPostUrl;

  final DateTime createdAt;

  const VideoQueueItem({
    required this.id,
    required this.filePath,
    required this.fileHash,
    this.aspectRatio,
    this.ytTitle,
    this.ytDesc,
    this.ytTags,
    this.igCaption,
    this.igHashtags,
    this.fbPostText,
    this.fbTags,
    this.coverFramePath,
    this.status = QueueStatus.pending,
    this.scheduledAt,
    this.uploadedAt,
    this.errorLog,
    this.ytPostUrl,
    this.igPostUrl,
    this.fbPostUrl,
    required this.createdAt,
  });

  VideoQueueItem copyWith({
    String? aspectRatio,
    String? ytTitle,
    String? ytDesc,
    String? ytTags,
    String? igCaption,
    String? igHashtags,
    String? fbPostText,
    String? fbTags,
    String? coverFramePath,
    QueueStatus? status,
    DateTime? scheduledAt,
    DateTime? uploadedAt,
    String? errorLog,
    String? ytPostUrl,
    String? igPostUrl,
    String? fbPostUrl,
  }) {
    return VideoQueueItem(
      id: id,
      filePath: filePath,
      fileHash: fileHash,
      aspectRatio: aspectRatio ?? this.aspectRatio,
      ytTitle: ytTitle ?? this.ytTitle,
      ytDesc: ytDesc ?? this.ytDesc,
      ytTags: ytTags ?? this.ytTags,
      igCaption: igCaption ?? this.igCaption,
      igHashtags: igHashtags ?? this.igHashtags,
      fbPostText: fbPostText ?? this.fbPostText,
      fbTags: fbTags ?? this.fbTags,
      coverFramePath: coverFramePath ?? this.coverFramePath,
      status: status ?? this.status,
      scheduledAt: scheduledAt ?? this.scheduledAt,
      uploadedAt: uploadedAt ?? this.uploadedAt,
      errorLog: errorLog ?? this.errorLog,
      ytPostUrl: ytPostUrl ?? this.ytPostUrl,
      igPostUrl: igPostUrl ?? this.igPostUrl,
      fbPostUrl: fbPostUrl ?? this.fbPostUrl,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'file_path': filePath,
      'file_hash': fileHash,
      'aspect_ratio': aspectRatio,
      'yt_title': ytTitle,
      'yt_desc': ytDesc,
      'yt_tags': ytTags,
      'ig_caption': igCaption,
      'ig_hashtags': igHashtags,
      'fb_post_text': fbPostText,
      'fb_tags': fbTags,
      'cover_frame_path': coverFramePath,
      'status': status.dbValue,
      'scheduled_at': scheduledAt?.toIso8601String(),
      'uploaded_at': uploadedAt?.toIso8601String(),
      'error_log': errorLog,
      'yt_post_url': ytPostUrl,
      'ig_post_url': igPostUrl,
      'fb_post_url': fbPostUrl,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory VideoQueueItem.fromMap(Map<String, dynamic> map) {
    return VideoQueueItem(
      id: map['id'] as String,
      filePath: map['file_path'] as String,
      fileHash: map['file_hash'] as String,
      aspectRatio: map['aspect_ratio'] as String?,
      ytTitle: map['yt_title'] as String?,
      ytDesc: map['yt_desc'] as String?,
      ytTags: map['yt_tags'] as String?,
      igCaption: map['ig_caption'] as String?,
      igHashtags: map['ig_hashtags'] as String?,
      fbPostText: map['fb_post_text'] as String?,
      fbTags: map['fb_tags'] as String?,
      coverFramePath: map['cover_frame_path'] as String?,
      status: QueueStatusX.fromDb(map['status'] as String),
      scheduledAt: map['scheduled_at'] != null ? DateTime.parse(map['scheduled_at']) : null,
      uploadedAt: map['uploaded_at'] != null ? DateTime.parse(map['uploaded_at']) : null,
      errorLog: map['error_log'] as String?,
      ytPostUrl: map['yt_post_url'] as String?,
      igPostUrl: map['ig_post_url'] as String?,
      fbPostUrl: map['fb_post_url'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
