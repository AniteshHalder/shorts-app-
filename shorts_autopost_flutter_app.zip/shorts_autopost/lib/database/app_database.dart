import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../core/constants.dart';
import 'models/video_queue_item.dart';

/// Singleton wrapper around the local SQLite database.
///
/// Table: video_queue
///   id, file_path, file_hash, aspect_ratio, yt_title, yt_desc, yt_tags,
///   ig_caption, ig_hashtags, fb_post_text, fb_tags, cover_frame_path,
///   status, scheduled_at, uploaded_at, error_log,
///   yt_post_url, ig_post_url, fb_post_url, created_at
///
/// `file_hash` carries a UNIQUE index — this is the enforcement point for
/// "once COMPLETED, a file can never be re-queued": duplicate inserts are
/// rejected outright, and completed rows are additionally filtered out of
/// every import path in VideoQueueDao.
class AppDatabase {
  AppDatabase._internal();
  static final AppDatabase instance = AppDatabase._internal();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'shorts_autopost.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE video_queue (
            id TEXT PRIMARY KEY,
            file_path TEXT NOT NULL,
            file_hash TEXT NOT NULL UNIQUE,
            aspect_ratio TEXT,
            yt_title TEXT,
            yt_desc TEXT,
            yt_tags TEXT,
            ig_caption TEXT,
            ig_hashtags TEXT,
            fb_post_text TEXT,
            fb_tags TEXT,
            cover_frame_path TEXT,
            status TEXT NOT NULL DEFAULT 'PENDING',
            scheduled_at TEXT,
            uploaded_at TEXT,
            error_log TEXT,
            yt_post_url TEXT,
            ig_post_url TEXT,
            fb_post_url TEXT,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX idx_queue_status ON video_queue(status)');
        await db.execute('CREATE UNIQUE INDEX idx_queue_hash ON video_queue(file_hash)');
      },
    );
  }
}

class VideoQueueDao {
  final _dbProvider = AppDatabase.instance;

  /// Returns true if this exact file (by content hash) has ever completed —
  /// used to hard-block re-import regardless of file path/rename.
  Future<bool> hasCompletedHash(String fileHash) async {
    final db = await _dbProvider.database;
    final rows = await db.query(
      'video_queue',
      where: 'file_hash = ? AND status = ?',
      whereArgs: [fileHash, QueueStatus.completed.dbValue],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  /// Insert a new item. Silently ignored (no duplicate row) if file_hash
  /// already exists — this is the DB-level half of duplicate prevention.
  Future<void> insert(VideoQueueItem item) async {
    final db = await _dbProvider.database;
    await db.insert(
      'video_queue',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<void> update(VideoQueueItem item) async {
    final db = await _dbProvider.database;
    await db.update('video_queue', item.toMap(), where: 'id = ?', whereArgs: [item.id]);
  }

  Future<VideoQueueItem?> getNextPending() async {
    final db = await _dbProvider.database;
    final rows = await db.query(
      'video_queue',
      where: 'status = ?',
      whereArgs: [QueueStatus.pending.dbValue],
      orderBy: 'created_at ASC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return VideoQueueItem.fromMap(rows.first);
  }

  Future<List<VideoQueueItem>> getAll() async {
    final db = await _dbProvider.database;
    final rows = await db.query('video_queue', orderBy: 'created_at DESC');
    return rows.map(VideoQueueItem.fromMap).toList();
  }

  Future<List<VideoQueueItem>> getByStatus(QueueStatus status) async {
    final db = await _dbProvider.database;
    final rows = await db.query(
      'video_queue',
      where: 'status = ?',
      whereArgs: [status.dbValue],
      orderBy: 'created_at DESC',
    );
    return rows.map(VideoQueueItem.fromMap).toList();
  }

  Future<Map<QueueStatus, int>> getCounts() async {
    final db = await _dbProvider.database;
    final result = <QueueStatus, int>{};
    for (final status in QueueStatus.values) {
      final rows = await db.rawQuery(
        'SELECT COUNT(*) as c FROM video_queue WHERE status = ?',
        [status.dbValue],
      );
      result[status] = Sqflite.firstIntValue(rows) ?? 0;
    }
    return result;
  }

  Future<void> delete(String id) async {
    final db = await _dbProvider.database;
    await db.delete('video_queue', where: 'id = ?', whereArgs: [id]);
  }
}
