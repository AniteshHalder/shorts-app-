import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../database/app_database.dart';
import '../database/models/video_queue_item.dart';
import '../services/video/video_import_service.dart';
import '../widgets/queue_item_card.dart';

class QueueScreen extends StatefulWidget {
  const QueueScreen({super.key});
  @override
  State<QueueScreen> createState() => _QueueScreenState();
}

class _QueueScreenState extends State<QueueScreen> {
  final _dao = VideoQueueDao();
  final _importer = VideoImportService();
  List<VideoQueueItem> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final items = await _dao.getAll();
    setState(() {
      _items = items;
      _loading = false;
    });
  }

  Future<void> _import() async {
    final summary = await _importer.pickAndImport();
    await _refresh();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
          'Added ${summary.added} video(s). Skipped ${summary.skippedDuplicates} already-completed duplicate(s).'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Video Queue'),
        actions: [
          IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _import,
        icon: const Icon(Icons.video_library_outlined),
        label: const Text('Bulk Import'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('Queue is empty. Import videos to get started.'))
              : RefreshIndicator(
                  onRefresh: _refresh,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount: _items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) => QueueItemCard(
                      item: _items[i],
                      onDelete: () async {
                        await _dao.delete(_items[i].id);
                        await _refresh();
                      },
                    ),
                  ),
                ),
    );
  }
}
