import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../services/secure_storage_service.dart';
import '../services/ai/ai_service_factory.dart';
import '../services/social/youtube_service.dart';
import '../services/social/meta_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _storage = SecureStorageService.instance;

  AiProvider _selectedProvider = AiProvider.geminiFlash;

  final _geminiCtrl = TextEditingController();
  final _openAiCtrl = TextEditingController();
  final _deepseekCtrl = TextEditingController();
  final _claudeCtrl = TextEditingController();
  final _customBaseUrlCtrl = TextEditingController();
  final _customKeyCtrl = TextEditingController();

  final _ytClientIdCtrl = TextEditingController();
  final _ytClientSecretCtrl = TextEditingController();
  final _ytAccessTokenCtrl = TextEditingController();

  final _metaPageTokenCtrl = TextEditingController();
  final _metaPageIdCtrl = TextEditingController();
  final _metaIgIdCtrl = TextEditingController();

  bool _loading = true;
  String? _aiTestResult;
  String? _ytTestResult;
  String? _metaTestResult;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    _selectedProvider = await _storage.getSelectedAiProvider();
    _geminiCtrl.text = await _storage.read(SecureKeys.geminiApiKey) ?? '';
    _openAiCtrl.text = await _storage.read(SecureKeys.openAiApiKey) ?? '';
    _deepseekCtrl.text = await _storage.read(SecureKeys.deepseekApiKey) ?? '';
    _claudeCtrl.text = await _storage.read(SecureKeys.claudeApiKey) ?? '';
    _customBaseUrlCtrl.text = await _storage.read(SecureKeys.customAiBaseUrl) ?? '';
    _customKeyCtrl.text = await _storage.read(SecureKeys.customAiApiKey) ?? '';

    _ytClientIdCtrl.text = await _storage.read(SecureKeys.youtubeOAuthClientId) ?? '';
    _ytClientSecretCtrl.text = await _storage.read(SecureKeys.youtubeOAuthClientSecret) ?? '';
    _ytAccessTokenCtrl.text = await _storage.read(SecureKeys.youtubeAccessToken) ?? '';

    _metaPageTokenCtrl.text = await _storage.read(SecureKeys.metaPageAccessToken) ?? '';
    _metaPageIdCtrl.text = await _storage.read(SecureKeys.metaPageId) ?? '';
    _metaIgIdCtrl.text = await _storage.read(SecureKeys.metaIgBusinessAccountId) ?? '';

    setState(() => _loading = false);
  }

  Future<void> _saveAiSettings() async {
    await _storage.setSelectedAiProvider(_selectedProvider);
    await _storage.write(SecureKeys.geminiApiKey, _geminiCtrl.text.trim());
    await _storage.write(SecureKeys.openAiApiKey, _openAiCtrl.text.trim());
    await _storage.write(SecureKeys.deepseekApiKey, _deepseekCtrl.text.trim());
    await _storage.write(SecureKeys.claudeApiKey, _claudeCtrl.text.trim());
    await _storage.write(SecureKeys.customAiBaseUrl, _customBaseUrlCtrl.text.trim());
    await _storage.write(SecureKeys.customAiApiKey, _customKeyCtrl.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('AI settings saved')));
    }
  }

  Future<void> _saveSocialSettings() async {
    await _storage.write(SecureKeys.youtubeOAuthClientId, _ytClientIdCtrl.text.trim());
    await _storage.write(SecureKeys.youtubeOAuthClientSecret, _ytClientSecretCtrl.text.trim());
    await _storage.write(SecureKeys.youtubeAccessToken, _ytAccessTokenCtrl.text.trim());
    await _storage.write(SecureKeys.metaPageAccessToken, _metaPageTokenCtrl.text.trim());
    await _storage.write(SecureKeys.metaPageId, _metaPageIdCtrl.text.trim());
    await _storage.write(SecureKeys.metaIgBusinessAccountId, _metaIgIdCtrl.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Social settings saved')));
    }
  }

  Future<void> _testAi() async {
    setState(() => _aiTestResult = 'Testing...');
    await _saveAiSettings();
    try {
      final service = await AiServiceFactory.build();
      final ok = await service.testConnection();
      setState(() => _aiTestResult = ok ? '✅ Connected' : '❌ Failed (check key)');
    } catch (e) {
      setState(() => _aiTestResult = '❌ $e');
    }
  }

  Future<void> _testYoutube() async {
    setState(() => _ytTestResult = 'Testing...');
    await _saveSocialSettings();
    final ok = await YoutubeService().testConnection();
    setState(() => _ytTestResult = ok ? '✅ Connected' : '❌ Failed — check access token');
  }

  Future<void> _testMeta() async {
    setState(() => _metaTestResult = 'Testing...');
    await _saveSocialSettings();
    final ok = await MetaService().testConnection();
    setState(() => _metaTestResult = ok ? '✅ Connected' : '❌ Failed — check page token/ID');
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionCard(
            title: 'AI Provider (Bring Your Own Key)',
            children: [
              DropdownButtonFormField<AiProvider>(
                value: _selectedProvider,
                decoration: const InputDecoration(labelText: 'Provider'),
                items: AiProvider.values
                    .map((p) => DropdownMenuItem(value: p, child: Text(p.displayName)))
                    .toList(),
                onChanged: (v) => setState(() => _selectedProvider = v!),
              ),
              const SizedBox(height: 12),
              _keyField('Gemini API Key', _geminiCtrl),
              _keyField('OpenAI API Key', _openAiCtrl),
              _keyField('DeepSeek API Key', _deepseekCtrl),
              _keyField('Claude API Key', _claudeCtrl),
              _keyField('Custom Base URL (e.g. https://api.groq.com/openai/v1)', _customBaseUrlCtrl,
                  isSecret: false),
              _keyField('Custom Provider API Key', _customKeyCtrl),
              const SizedBox(height: 8),
              Row(
                children: [
                  ElevatedButton(onPressed: _saveAiSettings, child: const Text('Save')),
                  const SizedBox(width: 12),
                  OutlinedButton(onPressed: _testAi, child: const Text('Test Connection')),
                  const SizedBox(width: 12),
                  if (_aiTestResult != null) Expanded(child: Text(_aiTestResult!)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          _sectionCard(
            title: 'YouTube Data API v3',
            children: [
              _keyField('OAuth Client ID', _ytClientIdCtrl, isSecret: false),
              _keyField('OAuth Client Secret', _ytClientSecretCtrl),
              _keyField('Access Token (or connect via OAuth flow)', _ytAccessTokenCtrl),
              Row(
                children: [
                  ElevatedButton(onPressed: _saveSocialSettings, child: const Text('Save')),
                  const SizedBox(width: 12),
                  OutlinedButton(onPressed: _testYoutube, child: const Text('Test Connection')),
                  const SizedBox(width: 12),
                  if (_ytTestResult != null) Expanded(child: Text(_ytTestResult!)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          _sectionCard(
            title: 'Meta Graph API (Facebook Page + Instagram)',
            children: [
              _keyField('Facebook Page Access Token', _metaPageTokenCtrl),
              _keyField('Facebook Page ID', _metaPageIdCtrl, isSecret: false),
              _keyField('Instagram Business Account ID', _metaIgIdCtrl, isSecret: false),
              Row(
                children: [
                  ElevatedButton(onPressed: _saveSocialSettings, child: const Text('Save')),
                  const SizedBox(width: 12),
                  OutlinedButton(onPressed: _testMeta, child: const Text('Test Connection')),
                  const SizedBox(width: 12),
                  if (_metaTestResult != null) Expanded(child: Text(_metaTestResult!)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sectionCard({required String title, required List<Widget> children}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _keyField(String label, TextEditingController ctrl, {bool isSecret = true}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        obscureText: isSecret,
        decoration: InputDecoration(labelText: label),
      ),
    );
  }
}
