import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../database/app_database.dart';
import '../services/scheduler/upload_pipeline.dart';
import '../services/scheduler/burst_scheduler.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _dao = VideoQueueDao();
  final _pipeline = UploadPipeline();
  final _scheduler = BurstScheduler();

  Map<QueueStatus, int> _counts = {
    for (final s in QueueStatus.values) s: 0,
  };
  final List<PipelineLogEvent> _logs = [];
  bool _isRunning = false;
  bool _schedulerEnabled = false;
  int _intervalMinutes = 180;

  @override
  void initState() {
    super.initState();
    _refreshCounts();
    _loadSchedulerState();
  }

  Future<void> _refreshCounts() async {
    final counts = await _dao.getCounts();
    setState(() => _counts = counts);
  }

  Future<void> _loadSchedulerState() async {
    final enabled = await _scheduler.isEnabled();
    final interval = await _scheduler.currentIntervalMinutes();
    setState(() {
      _schedulerEnabled = enabled;
      _intervalMinutes = interval;
    });
  }

  Future<void> _startUpload() async {
    setState(() => _isRunning = true);
    final processed = await _pipeline.processNext(
      onLog: (event) => setState(() => _logs.insert(0, event)),
    );
    await _refreshCounts();
    setState(() => _isRunning = false);
    if (!processed && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No pending videos in the queue.')),
      );
    }
  }

  Future<void> _toggleScheduler(bool value) async {
    if (value) {
      await _scheduler.enable(_intervalMinutes);
    } else {
      await _scheduler.disable();
    }
    setState(() => _schedulerEnabled = value);
  }

  Future<void> _pickInterval() async {
    final picked = await showDialog<int>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Posting interval'),
        children: [60, 120, 180, 240, 360]
            .map((m) => SimpleDialogOption(
                  onPressed: () => Navigator.pop(context, m),
                  child: Text(m < 60 ? '$m minutes' : '${m ~/ 60} hour(s)'),
                ))
            .toList(),
      ),
    );
    if (picked != null) {
      setState(() => _intervalMinutes = picked);
      if (_schedulerEnabled) await _scheduler.enable(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: RefreshIndicator(
        onRefresh: _refreshCounts,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                _counterCard('Pending', _counts[QueueStatus.pending] ?? 0, Colors.grey),
                const SizedBox(width: 8),
                _counterCard('Uploaded', _counts[QueueStatus.completed] ?? 0, Colors.greenAccent),
                const SizedBox(width: 8),
                _counterCard('Failed', _counts[QueueStatus.failed] ?? 0, Colors.redAccent),
              ],
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _isRunning ? null : _startUpload,
                icon: _isRunning
                    ? const SizedBox(
                        width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.rocket_launch_outlined),
                label: Text(_isRunning ? 'Processing…' : 'Start Upload (next pending video)'),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Burst Scheduler', style: Theme.of(context).textTheme.titleMedium),
                        Switch(value: _schedulerEnabled, onChanged: _toggleScheduler),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Automatically uploads one video every interval to avoid spam flags.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _pickInterval,
                      icon: const Icon(Icons.timer_outlined),
                      label: Text(_intervalMinutes < 60
                          ? '$_intervalMinutes minutes'
                          : '${_intervalMinutes ~/ 60} hour(s)'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('Live Upload Logs', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (_logs.isEmpty)
              const Text('No activity yet.', style: TextStyle(color: Colors.white54))
            else
              ..._logs.take(50).map((log) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Text(
                      '[${log.timestamp.hour.toString().padLeft(2, '0')}:${log.timestamp.minute.toString().padLeft(2, '0')}] ${log.message}',
                      style: TextStyle(
                        fontSize: 12,
                        color: log.isError ? Colors.redAccent : Colors.white70,
                        fontFamily: 'monospace',
                      ),
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  Widget _counterCard(String label, int value, Color color) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Text('$value', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color)),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
            ],
          ),
        ),
      ),
    );
  }
}
