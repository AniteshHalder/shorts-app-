import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/constants.dart';
import '../database/models/video_queue_item.dart';

class QueueItemCard extends StatelessWidget {
  final VideoQueueItem item;
  final VoidCallback onDelete;
  const QueueItemCard({super.key, required this.item, required this.onDelete});

  Color _statusColor(BuildContext context) {
    switch (item.status) {
      case QueueStatus.pending:
        return Colors.grey;
      case QueueStatus.processing:
        return Colors.amber;
      case QueueStatus.completed:
        return Colors.greenAccent;
      case QueueStatus.failed:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: item.coverFramePath != null && File(item.coverFramePath!).existsSync()
                  ? Image.file(File(item.coverFramePath!), width: 56, height: 96, fit: BoxFit.cover)
                  : Container(
                      width: 56,
                      height: 96,
                      color: Colors.white10,
                      child: const Icon(Icons.movie_outlined),
                    ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.basename(item.filePath),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: _statusColor(context).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(item.status.dbValue,
                            style: TextStyle(color: _statusColor(context), fontSize: 12)),
                      ),
                      const SizedBox(width: 8),
                      if (item.aspectRatio != null) Text(item.aspectRatio!, style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                  if (item.ytTitle != null) ...[
                    const SizedBox(height: 6),
                    Text(item.ytTitle!, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12, color: Colors.white70)),
                  ],
                  if (item.status == QueueStatus.completed) ...[
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      children: [
                        if (item.ytPostUrl != null) const _LinkChip(label: 'YouTube'),
                        if (item.fbPostUrl != null) const _LinkChip(label: 'Facebook'),
                        if (item.igPostUrl != null) const _LinkChip(label: 'Instagram'),
                      ],
                    ),
                  ],
                  if (item.status == QueueStatus.failed && item.errorLog != null) ...[
                    const SizedBox(height: 6),
                    Text(item.errorLog!, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, color: Colors.redAccent)),
                  ],
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, size: 20),
              onPressed: item.status == QueueStatus.processing ? null : onDelete,
            ),
          ],
        ),
      ),
    );
  }
}

class _LinkChip extends StatelessWidget {
  final String label;
  const _LinkChip({required this.label});
  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label, style: const TextStyle(fontSize: 11)),
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
  }
}
