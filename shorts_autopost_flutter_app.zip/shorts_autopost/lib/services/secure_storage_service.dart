import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/constants.dart';

/// Thin wrapper over flutter_secure_storage.
/// - iOS: stored in Keychain
/// - Android: stored in EncryptedSharedPreferences (AES-256, key in Android Keystore)
///
/// Nothing touching an AI key, a YouTube OAuth token, or a Meta access token
/// should ever be persisted anywhere except through this class.
class SecureStorageService {
  SecureStorageService._internal();
  static final SecureStorageService instance = SecureStorageService._internal();

  final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
  );

  Future<void> write(String key, String? value) async {
    if (value == null || value.isEmpty) {
      await _storage.delete(key: key);
    } else {
      await _storage.write(key: key, value: value);
    }
  }

  Future<String?> read(String key) => _storage.read(key: key);

  Future<void> deleteAll() => _storage.deleteAll();

  // ---- Convenience typed getters/setters for the AI provider selection ----

  Future<void> setSelectedAiProvider(AiProvider provider) =>
      write(SecureKeys.selectedAiProvider, provider.name);

  Future<AiProvider> getSelectedAiProvider() async {
    final raw = await read(SecureKeys.selectedAiProvider);
    if (raw == null) return AiProvider.geminiFlash;
    return AiProvider.values.firstWhere(
      (p) => p.name == raw,
      orElse: () => AiProvider.geminiFlash,
    );
  }

  /// Returns the correct stored API key for whichever provider is active.
  Future<String?> getApiKeyFor(AiProvider provider) {
    switch (provider) {
      case AiProvider.geminiFlash:
      case AiProvider.geminiPro:
        return read(SecureKeys.geminiApiKey);
      case AiProvider.gpt4o:
      case AiProvider.gpt4oMini:
        return read(SecureKeys.openAiApiKey);
      case AiProvider.deepseekV3:
      case AiProvider.deepseekR1:
        return read(SecureKeys.deepseekApiKey);
      case AiProvider.claude35Sonnet:
        return read(SecureKeys.claudeApiKey);
      case AiProvider.customOpenAiCompatible:
        return read(SecureKeys.customAiApiKey);
    }
  }
}
