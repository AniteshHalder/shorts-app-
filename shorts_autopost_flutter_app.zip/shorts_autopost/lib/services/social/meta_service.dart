import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../secure_storage_service.dart';
import '../../core/constants.dart';

class MetaPublishResult {
  final String postId;
  final String url;
  MetaPublishResult(this.postId, this.url);
}

/// Publishes to Facebook Page Reels and Instagram Reels via the Meta Graph
/// API. Both flows require the video to be reachable at a public HTTPS URL
/// (Graph API pulls the file server-side) — in this scaffold that means the
/// local file must first be uploaded to the user's own storage/CDN or
/// through Facebook's resumable "rupload" endpoint, which is what
/// [uploadFacebookReel] does directly with the local file.
class MetaService {
  final _storage = SecureStorageService.instance;
  static const _graphVersion = 'v19.0';

  Future<String> _pageToken() async {
    final t = await _storage.read(SecureKeys.metaPageAccessToken);
    if (t == null) throw StateError('Meta Page Access Token not set in Settings.');
    return t;
  }

  Future<String> _pageId() async {
    final id = await _storage.read(SecureKeys.metaPageId);
    if (id == null) throw StateError('Facebook Page ID not set in Settings.');
    return id;
  }

  Future<String> _igBusinessId() async {
    final id = await _storage.read(SecureKeys.metaIgBusinessAccountId);
    if (id == null) throw StateError('Instagram Business Account ID not set in Settings.');
    return id;
  }

  Future<bool> testConnection() async {
    try {
      final token = await _pageToken();
      final pageId = await _pageId();
      final resp = await http
          .get(Uri.parse('https://graph.facebook.com/$_graphVersion/$pageId?fields=id,name&access_token=$token'));
      return resp.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ---------------- Facebook Page Reels ----------------

  /// Facebook's video_reels endpoint uses a 3-step resumable protocol:
  /// start -> upload bytes -> publish (finish).
  Future<MetaPublishResult> uploadFacebookReel({
    required File videoFile,
    required String description,
  }) async {
    final token = await _pageToken();
    final pageId = await _pageId();

    // Step 1: start upload session.
    final startResp = await http.post(
      Uri.parse('https://graph.facebook.com/$_graphVersion/$pageId/video_reels'),
      body: {'upload_phase': 'start', 'access_token': token},
    );
    final startData = jsonDecode(startResp.body) as Map<String, dynamic>;
    if (startResp.statusCode != 200 || startData['video_id'] == null) {
      throw Exception('FB reel init failed: ${startResp.body}');
    }
    final videoId = startData['video_id'] as String;
    final uploadUrl = startData['upload_url'] as String;

    // Step 2: upload raw bytes to the rupload endpoint.
    final bytes = await videoFile.readAsBytes();
    final uploadResp = await http.post(
      Uri.parse(uploadUrl),
      headers: {
        'Authorization': 'OAuth $token',
        'offset': '0',
        'file_size': '${bytes.length}',
      },
      body: bytes,
    );
    if (uploadResp.statusCode != 200) {
      throw Exception('FB reel byte upload failed: ${uploadResp.body}');
    }

    // Step 3: publish/finish.
    final finishResp = await http.post(
      Uri.parse('https://graph.facebook.com/$_graphVersion/$pageId/video_reels'),
      body: {
        'upload_phase': 'finish',
        'video_id': videoId,
        'video_state': 'PUBLISHED',
        'description': description,
        'access_token': token,
      },
    );
    if (finishResp.statusCode != 200) {
      throw Exception('FB reel publish failed: ${finishResp.body}');
    }
    return MetaPublishResult(videoId, 'https://www.facebook.com/reel/$videoId');
  }

  // ---------------- Instagram Reels ----------------

  /// IG Reels publishing is a 2-step container flow and REQUIRES the video
  /// to already be at a public HTTPS URL (video_url param) — it cannot take
  /// raw bytes directly like the Facebook rupload endpoint above.
  /// [publicVideoUrl] should point at a file already pushed to the user's
  /// own storage/CDN (e.g. their connected Google Drive, made link-public,
  /// or an intermediary bucket) by the video pipeline before this call.
  Future<MetaPublishResult> publishInstagramReel({
    required String publicVideoUrl,
    required String caption,
    String? coverPublicUrl,
  }) async {
    final token = await _pageToken();
    final igUserId = await _igBusinessId();

    // Step 1: create media container.
    final createResp = await http.post(
      Uri.parse('https://graph.facebook.com/$_graphVersion/$igUserId/media'),
      body: {
        'media_type': 'REELS',
        'video_url': publicVideoUrl,
        'caption': caption,
        if (coverPublicUrl != null) 'cover_url': coverPublicUrl,
        'access_token': token,
      },
    );
    final createData = jsonDecode(createResp.body) as Map<String, dynamic>;
    if (createResp.statusCode != 200 || createData['id'] == null) {
      throw Exception('IG container creation failed: ${createResp.body}');
    }
    final containerId = createData['id'] as String;

    // Step 2: poll container status until FINISHED (Meta processes the video async).
    await _pollUntilReady(containerId, token);

    // Step 3: publish.
    final publishResp = await http.post(
      Uri.parse('https://graph.facebook.com/$_graphVersion/$igUserId/media_publish'),
      body: {'creation_id': containerId, 'access_token': token},
    );
    final publishData = jsonDecode(publishResp.body) as Map<String, dynamic>;
    if (publishResp.statusCode != 200 || publishData['id'] == null) {
      throw Exception('IG publish failed: ${publishResp.body}');
    }
    final mediaId = publishData['id'] as String;
    return MetaPublishResult(mediaId, 'https://www.instagram.com/reel/$mediaId');
  }

  Future<void> _pollUntilReady(String containerId, String token, {int maxAttempts = 20}) async {
    for (var i = 0; i < maxAttempts; i++) {
      final resp = await http.get(Uri.parse(
          'https://graph.facebook.com/$_graphVersion/$containerId?fields=status_code&access_token=$token'));
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final status = data['status_code'];
      if (status == 'FINISHED') return;
      if (status == 'ERROR') throw Exception('IG container processing failed.');
      await Future.delayed(const Duration(seconds: 3));
    }
    throw Exception('IG container timed out waiting to finish processing.');
  }
}
