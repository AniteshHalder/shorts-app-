import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../secure_storage_service.dart';
import '../../core/constants.dart';

class YoutubeUploadResult {
  final String videoId;
  final String url;
  YoutubeUploadResult(this.videoId) : url = 'https://youtube.com/shorts/$videoId';
}

/// Publishes a vertical video as a YouTube Short via the resumable-upload
/// flow of the Data API v3 (videos.insert, uploadType=resumable).
/// Adding "#Shorts" to the title/description plus a <=60s, <=16:9-portrait
/// video is what makes YouTube classify it as a Short.
class YoutubeService {
  final _storage = SecureStorageService.instance;

  static const _uploadInitUrl =
      'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status';

  Future<String> _accessToken() async {
    final token = await _storage.read(SecureKeys.youtubeAccessToken);
    if (token == null) {
      throw StateError('YouTube not connected. Authorize it in Settings first.');
    }
    // NOTE: production build should check expiry and refresh via
    // SecureKeys.youtubeRefreshToken + the OAuth client id/secret before
    // every call; refresh logic omitted here for brevity of this scaffold.
    return token;
  }

  Future<bool> testConnection() async {
    try {
      final token = await _accessToken();
      final resp = await http.get(
        Uri.parse('https://www.googleapis.com/youtube/v3/channels?part=id&mine=true'),
        headers: {'Authorization': 'Bearer $token'},
      );
      return resp.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  Future<YoutubeUploadResult> uploadShort({
    required File videoFile,
    required String title,
    required String description,
    required List<String> tags,
  }) async {
    final token = await _accessToken();
    final safeTitle =
        title.length > kMaxYoutubeTitleChars ? title.substring(0, kMaxYoutubeTitleChars) : title;

    final metadata = {
      'snippet': {
        'title': safeTitle,
        'description': description,
        'tags': tags,
        'categoryId': '22',
      },
      'status': {
        'privacyStatus': 'public',
        'selfDeclaredMadeForKids': false,
      },
    };

    final fileLength = await videoFile.length();

    // Step 1: initiate resumable session.
    final initResp = await http.post(
      Uri.parse(_uploadInitUrl),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json; charset=UTF-8',
        'X-Upload-Content-Type': 'video/*',
        'X-Upload-Content-Length': '$fileLength',
      },
      body: jsonEncode(metadata),
    );
    if (initResp.statusCode != 200) {
      throw Exception('YouTube upload init failed: ${initResp.statusCode} ${initResp.body}');
    }
    final uploadUrl = initResp.headers['location'];
    if (uploadUrl == null) {
      throw Exception('YouTube did not return a resumable upload URL.');
    }

    // Step 2: PUT the raw bytes.
    final bytes = await videoFile.readAsBytes();
    final uploadResp = await http.put(
      Uri.parse(uploadUrl),
      headers: {
        'Content-Type': 'video/*',
        'Content-Length': '$fileLength',
      },
      body: bytes,
    );
    if (uploadResp.statusCode != 200 && uploadResp.statusCode != 201) {
      throw Exception('YouTube upload failed: ${uploadResp.statusCode} ${uploadResp.body}');
    }

    final result = jsonDecode(uploadResp.body) as Map<String, dynamic>;
    return YoutubeUploadResult(result['id'] as String);
  }
}
