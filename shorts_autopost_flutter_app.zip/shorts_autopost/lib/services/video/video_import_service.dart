import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:uuid/uuid.dart';
import 'package:file_picker/file_picker.dart';
import '../../core/constants.dart';
import '../../database/app_database.dart';
import '../../database/models/video_queue_item.dart';

class ImportSummary {
  final int added;
  final int skippedDuplicates;
  ImportSummary(this.added, this.skippedDuplicates);
}

/// Handles bulk local file import and enforces the "never re-queue a
/// COMPLETED file" rule at import time (in addition to the DB UNIQUE
/// constraint on file_hash, which is the last line of defense).
class VideoImportService {
  final _dao = VideoQueueDao();

  Future<String> _hashFile(File file) async {
    final bytes = await file.readAsBytes();
    return sha256.convert(bytes).toString();
  }

  Future<ImportSummary> pickAndImport() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['mp4', 'mov'],
    );
    if (result == null) return ImportSummary(0, 0);

    int added = 0;
    int skipped = 0;

    for (final picked in result.files) {
      final path = picked.path;
      if (path == null) continue;
      final file = File(path);
      final hash = await _hashFile(file);

      final alreadyCompleted = await _dao.hasCompletedHash(hash);
      if (alreadyCompleted) {
        skipped++;
        continue;
      }

      final item = VideoQueueItem(
        id: const Uuid().v4(),
        filePath: path,
        fileHash: hash,
        status: QueueStatus.pending,
        createdAt: DateTime.now(),
      );
      await _dao.insert(item); // no-op if hash already exists (any status)
      added++;
    }
    return ImportSummary(added, skipped);
  }
}
