import 'dart:io';
import 'package:ffmpeg_kit_flutter/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter/return_code.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class VideoProbeResult {
  final int width;
  final int height;
  final double aspectRatio; // width / height
  final Duration duration;
  VideoProbeResult(this.width, this.height, this.aspectRatio, this.duration);

  bool get isVertical => aspectRatio < 0.8; // ~9:16 territory
}

/// Handles the "9:16 Vertical Video Enforcer" and "Auto Cover Frame
/// Extraction" requirements using ffmpeg_kit under the hood.
class VideoProcessorService {
  /// Probes width/height/duration via ffprobe (bundled with ffmpeg_kit).
  Future<VideoProbeResult> probe(File videoFile) async {
    final session = await FFmpegKit.execute(
      '-i "${videoFile.path}" -hide_banner',
    );
    final output = await session.getOutput() ?? '';
    // ffmpeg prints stream info to stderr; ffmpeg_kit merges logs, so we
    // parse the "Stream #0:0(...): Video: ... WxH" line and "Duration:".
    final resMatch = RegExp(r'(\d{2,5})x(\d{2,5})').firstMatch(output);
    final durMatch = RegExp(r'Duration:\s*(\d+):(\d+):(\d+\.\d+)').firstMatch(output);

    final width = int.tryParse(resMatch?.group(1) ?? '') ?? 1080;
    final height = int.tryParse(resMatch?.group(2) ?? '') ?? 1920;
    Duration duration = Duration.zero;
    if (durMatch != null) {
      duration = Duration(
        hours: int.parse(durMatch.group(1)!),
        minutes: int.parse(durMatch.group(2)!),
        seconds: double.parse(durMatch.group(3)!).round(),
      );
    }
    return VideoProbeResult(width, height, width / height, duration);
  }

  /// If the source is horizontal/square, re-encodes to a 1080x1920 canvas
  /// with the original video centered and a blurred, scaled-up copy of the
  /// same frame filling the top/bottom padding (the common "blur pad" look).
  /// Returns the path to the processed (or original, if already vertical) file.
  Future<String> enforceVerticalAspect(File videoFile, VideoProbeResult probe) async {
    if (probe.isVertical) return videoFile.path;

    final dir = await getTemporaryDirectory();
    final outPath = p.join(dir.path, '${p.basenameWithoutExtension(videoFile.path)}_9x16.mp4');

    // Filter graph:
    //  [0]-> split into fg/bg
    //  bg -> scale to fill 1080x1920, boxblur
    //  fg -> scale to fit width 1080, keep aspect
    //  overlay fg centered on bg
    const filter = '''
      split=2[bg][fg];
      [bg]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:5[bgblur];
      [fg]scale=1080:-2[fgscaled];
      [bgblur][fgscaled]overlay=(W-w)/2:(H-h)/2,format=yuv420p
    ''';

    final cmd =
        '-y -i "${videoFile.path}" -filter_complex "${filter.replaceAll('\n', '').replaceAll(' ', '')}" '
        '-c:a copy "$outPath"';

    final session = await FFmpegKit.execute(cmd);
    final rc = await session.getReturnCode();
    if (!ReturnCode.isSuccess(rc)) {
      throw Exception('ffmpeg vertical-pad failed for ${videoFile.path}');
    }
    return outPath;
  }

  /// Extracts the "sharpest, highest-energy" frame as a thumbnail candidate.
  /// Approach: sample N candidate timestamps, score each frame's Laplacian-
  /// style edge energy via ffmpeg's `edgedetect` + histogram, keep the max.
  /// (A lightweight heuristic suitable for on-device use, not a full CV pipeline.)
  Future<String> extractSharpestFrame(File videoFile, VideoProbeResult probe) async {
    final dir = await getTemporaryDirectory();
    final candidateCount = 5;
    final totalSeconds = probe.duration.inSeconds.clamp(1, 600);
    final step = totalSeconds / (candidateCount + 1);

    String bestPath = '';
    double bestScore = -1;

    for (var i = 1; i <= candidateCount; i++) {
      final ts = (step * i).toStringAsFixed(2);
      final framePath = p.join(dir.path, '${p.basenameWithoutExtension(videoFile.path)}_frame_$i.png');

      await FFmpegKit.execute(
        '-y -ss $ts -i "${videoFile.path}" -frames:v 1 "$framePath"',
      );

      final scoreSession = await FFmpegKit.execute(
        '-i "$framePath" -vf edgedetect,signalstats -f null -',
      );
      final log = await scoreSession.getOutput() ?? '';
      // Rough proxy: count of high-intensity ("YAVG" luma average) reported
      // by signalstats correlates with edge density for this heuristic.
      final match = RegExp(r'YAVG:([\d.]+)').firstMatch(log);
      final score = double.tryParse(match?.group(1) ?? '0') ?? 0;

      if (score > bestScore) {
        bestScore = score;
        bestPath = framePath;
      }
    }
    return bestPath.isEmpty
        ? await _fallbackMidpointFrame(videoFile, probe, dir.path)
        : bestPath;
  }

  Future<String> _fallbackMidpointFrame(File videoFile, VideoProbeResult probe, String dirPath) async {
    final framePath = p.join(dirPath, '${p.basenameWithoutExtension(videoFile.path)}_fallback.png');
    final mid = (probe.duration.inSeconds / 2).toStringAsFixed(2);
    await FFmpegKit.execute('-y -ss $mid -i "${videoFile.path}" -frames:v 1 "$framePath"');
    return framePath;
  }
}
