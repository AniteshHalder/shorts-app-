import 'dart:io';
import '../../core/constants.dart';
import '../../database/app_database.dart';
import '../../database/models/video_queue_item.dart';
import '../ai/ai_service_factory.dart';
import '../social/youtube_service.dart';
import '../social/meta_service.dart';
import '../video/video_processor_service.dart';

/// A single log line emitted while processing one item — feeds the Live
/// Upload Logs panel on the Dashboard.
class PipelineLogEvent {
  final String queueItemId;
  final String message;
  final bool isError;
  final DateTime timestamp;
  PipelineLogEvent(this.queueItemId, this.message, {this.isError = false})
      : timestamp = DateTime.now();
}

typedef LogSink = void Function(PipelineLogEvent event);

/// The engine behind the "Start Upload" button and the burst scheduler.
/// Always processes exactly ONE pending item per call — callers (manual
/// trigger or WorkManager task) decide the cadence.
class UploadPipeline {
  final _dao = VideoQueueDao();
  final _videoProcessor = VideoProcessorService();
  final _youtube = YoutubeService();
  final _meta = MetaService();

  /// Processes the single oldest PENDING item, if any.
  /// Returns true if an item was found and processed (regardless of success/failure),
  /// false if the queue was empty.
  Future<bool> processNext({LogSink? onLog}) async {
    final item = await _dao.getNextPending();
    if (item == null) return false;

    void log(String msg, {bool isError = false}) {
      onLog?.call(PipelineLogEvent(item.id, msg, isError: isError));
    }

    var current = item.copyWith(status: QueueStatus.processing);
    await _dao.update(current);
    log('Processing started for ${current.filePath}');

    try {
      final file = File(current.filePath);
      if (!await file.exists()) {
        throw Exception('File missing on disk: ${current.filePath}');
      }

      // 1. Probe + enforce 9:16.
      final probe = await _videoProcessor.probe(file);
      log('Probed video: ${probe.width}x${probe.height}, aspect=${probe.aspectRatio.toStringAsFixed(2)}');
      final processedPath = await _videoProcessor.enforceVerticalAspect(file, probe);
      if (processedPath != file.path) {
        log('Applied 9:16 blur-pad enforcement -> $processedPath');
      }
      final processedFile = File(processedPath);

      // 2. Extract cover frame.
      final coverPath = await _videoProcessor.extractSharpestFrame(processedFile, probe);
      log('Extracted cover frame -> $coverPath');
      current = current.copyWith(aspectRatio: '9:16', coverFramePath: coverPath);
      await _dao.update(current);

      // 3. AI metadata generation (single call, all 3 platforms).
      final ai = await AiServiceFactory.build();
      final videoContext =
          'Filename: ${file.uri.pathSegments.last}. Duration: ${probe.duration.inSeconds}s. Vertical short-form video.';
      final metadata = await ai.generateMetadata(videoContextDescription: videoContext);
      log('AI metadata generated (title: "${metadata.ytTitle}")');

      current = current.copyWith(
        ytTitle: metadata.ytTitle,
        ytDesc: metadata.ytDescription,
        ytTags: metadata.ytTags.join(','),
        igCaption: metadata.igCaption,
        igHashtags: metadata.igHashtags.join(' '),
        fbPostText: metadata.fbPostText,
        fbTags: metadata.fbTags.join(','),
      );
      await _dao.update(current);

      // 4. Publish — YouTube.
      String? ytUrl;
      try {
        final ytResult = await _youtube.uploadShort(
          videoFile: processedFile,
          title: metadata.ytTitle,
          description: metadata.ytDescription,
          tags: metadata.ytTags,
        );
        ytUrl = ytResult.url;
        log('Published to YouTube: $ytUrl');
      } catch (e) {
        log('YouTube publish failed: $e', isError: true);
      }

      // 5. Publish — Facebook Reels.
      String? fbUrl;
      try {
        final fbResult = await _meta.uploadFacebookReel(
          videoFile: processedFile,
          description: '${metadata.fbPostText}\n\n${metadata.fbTags.map((t) => '#$t').join(' ')}',
        );
        fbUrl = fbResult.url;
        log('Published to Facebook Reels: $fbUrl');
      } catch (e) {
        log('Facebook publish failed: $e', isError: true);
      }

      // 6. Publish — Instagram Reels.
      // NOTE: requires processedFile to already be reachable at a public
      // HTTPS URL; wire this to your storage/CDN uploader in production.
      String? igUrl;
      try {
        final caption = '${metadata.igCaption}\n\n${metadata.igHashtags.join(' ')}';
        log('Instagram publish requires a public video URL — skipping unless configured.');
        // final igResult = await _meta.publishInstagramReel(
        //   publicVideoUrl: <uploaded-to-cdn-url>,
        //   caption: caption,
        // );
        // igUrl = igResult.url;
      } catch (e) {
        log('Instagram publish failed: $e', isError: true);
      }

      final anySucceeded = ytUrl != null || fbUrl != null || igUrl != null;
      current = current.copyWith(
        status: anySucceeded ? QueueStatus.completed : QueueStatus.failed,
        uploadedAt: DateTime.now(),
        ytPostUrl: ytUrl,
        fbPostUrl: fbUrl,
        igPostUrl: igUrl,
        errorLog: anySucceeded ? null : 'All platform publishes failed — see logs.',
      );
      await _dao.update(current);
      log(anySucceeded ? 'Item marked COMPLETED.' : 'Item marked FAILED — no platform succeeded.',
          isError: !anySucceeded);
      return true;
    } catch (e) {
      current = current.copyWith(status: QueueStatus.failed, errorLog: e.toString());
      await _dao.update(current);
      log('Processing failed: $e', isError: true);
      return true;
    }
  }
}
