import 'package:workmanager/workmanager.dart';
import '../secure_storage_service.dart';
import '../../core/constants.dart';
import 'upload_pipeline.dart';

const String kBurstUploadTaskName = 'burst_upload_task';
const String kBurstUploadUniqueName = 'shorts_autopost_burst_upload';

/// Entry point WorkManager calls in the background isolate. Must be a
/// top-level or static function, registered once via Workmanager().initialize
/// in main.dart.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == kBurstUploadTaskName) {
      final pipeline = UploadPipeline();
      // Process exactly one item per background tick — keeps each run short
      // and lets the configured interval act as the natural spacing between
      // posts (the "burst gap" that avoids tripping platform spam flags).
      await pipeline.processNext();
    }
    return Future.value(true);
  });
}

/// Controls enabling/disabling/reconfiguring the periodic background task.
class BurstScheduler {
  final _storage = SecureStorageService.instance;

  Future<void> init() async {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  }

  /// [intervalMinutes] should be the user-configured gap, e.g. 180 (3h) or
  /// 240 (4h). WorkManager's Android periodic task floor is 15 minutes.
  Future<void> enable(int intervalMinutes) async {
    final clamped = intervalMinutes < 15 ? 15 : intervalMinutes;
    await _storage.write(SecureKeys.burstIntervalMinutes, '$clamped');
    await _storage.write(SecureKeys.schedulerEnabled, 'true');

    await Workmanager().registerPeriodicTask(
      kBurstUploadUniqueName,
      kBurstUploadTaskName,
      frequency: Duration(minutes: clamped),
      constraints: Constraints(
        networkType: NetworkType.connected,
        requiresBatteryNotLow: true,
      ),
      existingWorkPolicy: ExistingWorkPolicy.replace,
    );
  }

  Future<void> disable() async {
    await _storage.write(SecureKeys.schedulerEnabled, 'false');
    await Workmanager().cancelByUniqueName(kBurstUploadUniqueName);
  }

  Future<bool> isEnabled() async {
    return (await _storage.read(SecureKeys.schedulerEnabled)) == 'true';
  }

  Future<int> currentIntervalMinutes() async {
    final raw = await _storage.read(SecureKeys.burstIntervalMinutes);
    return int.tryParse(raw ?? '') ?? 180; // default 3 hours
  }
}
