import 'dart:convert';
import 'package:http/http.dart' as http;
import 'ai_provider.dart';

class GeminiService implements AiProviderService {
  final String apiKey;
  final String modelId; // gemini-1.5-flash | gemini-1.5-pro

  GeminiService({required this.apiKey, required this.modelId});

  Uri get _endpoint => Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent?key=$apiKey');

  @override
  Future<AiGeneratedMetadata> generateMetadata({
    required String videoContextDescription,
    String? niche,
  }) async {
    final prompt = buildMetadataPrompt(videoContext: videoContextDescription, niche: niche);
    final resp = await http.post(
      _endpoint,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': prompt}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.8,
          'responseMimeType': 'application/json',
        },
      }),
    );
    if (resp.statusCode != 200) {
      throw Exception('Gemini API error ${resp.statusCode}: ${resp.body}');
    }
    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final text = data['candidates'][0]['content']['parts'][0]['text'] as String;
    return parseModelJson(text);
  }

  @override
  Future<bool> testConnection() async {
    final resp = await http.post(
      _endpoint,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': 'Reply with the single word OK.'}
            ]
          }
        ]
      }),
    );
    return resp.statusCode == 200;
  }
}
