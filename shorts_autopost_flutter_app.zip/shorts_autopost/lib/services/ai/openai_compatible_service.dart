import 'dart:convert';
import 'package:http/http.dart' as http;
import 'ai_provider.dart';

/// Covers OpenAI, DeepSeek, and any Custom OpenAI-Compatible base URL
/// (Groq, Mistral, local Ollama, etc.) — they all speak the same
/// `POST /chat/completions` shape, so one implementation serves all three
/// Settings dropdown entries via a different [baseUrl] / [modelId].
class OpenAiCompatibleService implements AiProviderService {
  final String apiKey;
  final String modelId;
  final String baseUrl; // e.g. https://api.openai.com/v1, https://api.deepseek.com, custom
  final bool supportsJsonMode;

  OpenAiCompatibleService({
    required this.apiKey,
    required this.modelId,
    required this.baseUrl,
    this.supportsJsonMode = true,
  });

  Uri get _endpoint => Uri.parse('$baseUrl/chat/completions');

  @override
  Future<AiGeneratedMetadata> generateMetadata({
    required String videoContextDescription,
    String? niche,
  }) async {
    final prompt = buildMetadataPrompt(videoContext: videoContextDescription, niche: niche);
    final body = {
      'model': modelId,
      'messages': [
        {'role': 'system', 'content': 'You output only valid JSON, never markdown.'},
        {'role': 'user', 'content': prompt},
      ],
      'temperature': 0.8,
      if (supportsJsonMode) 'response_format': {'type': 'json_object'},
    };

    final resp = await http.post(
      _endpoint,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode(body),
    );
    if (resp.statusCode != 200) {
      throw Exception('AI provider error ${resp.statusCode}: ${resp.body}');
    }
    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final content = data['choices'][0]['message']['content'] as String;
    return parseModelJson(content);
  }

  @override
  Future<bool> testConnection() async {
    final resp = await http.post(
      _endpoint,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'model': modelId,
        'messages': [
          {'role': 'user', 'content': 'Reply with the single word OK.'}
        ],
        'max_tokens': 5,
      }),
    );
    return resp.statusCode == 200;
  }
}
