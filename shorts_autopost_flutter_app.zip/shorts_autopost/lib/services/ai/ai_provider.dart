import 'dart:convert';
import '../../core/constants.dart';

/// The structured metadata the AI must return for one video, across all
/// three platforms, in a single call — keeps token cost down vs 3 calls.
class AiGeneratedMetadata {
  final String ytTitle; // <= 60 chars, contains #Shorts
  final String ytDescription;
  final List<String> ytTags; // 3-5 tags
  final String igCaption; // hook line + emoji-spaced caption
  final List<String> igHashtags; // exactly 15: 5 viral + 5 niche + 5 micro
  final String fbPostText; // conversational + CTA
  final List<String> fbTags; // 3-5 broad tags

  AiGeneratedMetadata({
    required this.ytTitle,
    required this.ytDescription,
    required this.ytTags,
    required this.igCaption,
    required this.igHashtags,
    required this.fbPostText,
    required this.fbTags,
  });

  factory AiGeneratedMetadata.fromJson(Map<String, dynamic> json) {
    List<String> _strList(dynamic v) =>
        (v as List).map((e) => e.toString()).toList();
    return AiGeneratedMetadata(
      ytTitle: (json['yt_title'] as String).trim(),
      ytDescription: (json['yt_description'] as String).trim(),
      ytTags: _strList(json['yt_tags']),
      igCaption: (json['ig_caption'] as String).trim(),
      igHashtags: _strList(json['ig_hashtags']),
      fbPostText: (json['fb_post_text'] as String).trim(),
      fbTags: _strList(json['fb_tags']),
    );
  }
}

/// Every provider (Gemini / OpenAI / DeepSeek / Claude / custom-compatible)
/// implements this single method. Callers never branch on provider type.
abstract class AiProviderService {
  Future<AiGeneratedMetadata> generateMetadata({
    required String videoContextDescription, // filename, transcript snippet, or user notes
    String? niche, // optional user-provided channel niche for better targeting
  });

  /// Cheap call used by the Settings "Test Connection" button.
  Future<bool> testConnection();
}

/// Shared prompt template — every concrete provider sends this same
/// structured JSON-mode prompt so outputs stay consistent across vendors.
String buildMetadataPrompt({required String videoContext, String? niche}) {
  final nicheClause = (niche != null && niche.isNotEmpty)
      ? 'The channel niche is: "$niche". Tailor tone and hashtags to this niche.'
      : '';

  return '''
You are a short-form video growth strategist. Given the video context below,
generate platform-optimized publishing metadata. $nicheClause

VIDEO CONTEXT:
$videoContext

Return ONLY a single JSON object (no markdown fences, no preamble) with this
exact shape:

{
  "yt_title": "string, maximum $kMaxYoutubeTitleChars characters, high-CTR, MUST contain #Shorts",
  "yt_description": "string, SEO-rich, 2-4 sentences",
  "yt_tags": ["3 to 5 high-search-volume tags"],
  "ig_caption": "string, opens with a punchy 1-line curiosity hook, then an aesthetic emoji-spaced caption",
  "ig_hashtags": ["exactly $kIgHashtagCount hashtags total: 5 viral/broad, 5 niche-relevant, 5 micro/long-tail, each starting with #"],
  "fb_post_text": "string, conversational tone with a clear call-to-action to share or comment",
  "fb_tags": ["$kFbTagCount broad tags"]
}

Rules:
- yt_title must never exceed $kMaxYoutubeTitleChars characters including the #Shorts tag.
- ig_hashtags array length must be exactly $kIgHashtagCount.
- Output valid, parseable JSON only.
''';
}

AiGeneratedMetadata parseModelJson(String raw) {
  // Models sometimes wrap JSON in ```json fences despite instructions — strip defensively.
  final cleaned = raw.trim().replaceAll(RegExp(r'^```json|```$', multiLine: true), '').trim();
  final decoded = jsonDecode(cleaned) as Map<String, dynamic>;
  return AiGeneratedMetadata.fromJson(decoded);
}
