import '../../core/constants.dart';
import '../secure_storage_service.dart';
import 'ai_provider.dart';
import 'claude_service.dart';
import 'gemini_service.dart';
import 'openai_compatible_service.dart';

/// Reads the currently selected provider + its securely-stored key(s) and
/// builds a ready-to-use AiProviderService. This is the ONLY place that
/// needs to know about every concrete provider class — the rest of the app
/// just calls AiServiceFactory.build().generateMetadata(...).
class AiServiceFactory {
  static Future<AiProviderService> build() async {
    final storage = SecureStorageService.instance;
    final provider = await storage.getSelectedAiProvider();
    final apiKey = await storage.getApiKeyFor(provider);

    if (apiKey == null || apiKey.isEmpty) {
      throw StateError(
          'No API key configured for ${provider.displayName}. Add one in Settings.');
    }

    switch (provider) {
      case AiProvider.geminiFlash:
      case AiProvider.geminiPro:
        return GeminiService(apiKey: apiKey, modelId: provider.modelId);

      case AiProvider.gpt4o:
      case AiProvider.gpt4oMini:
        return OpenAiCompatibleService(
          apiKey: apiKey,
          modelId: provider.modelId,
          baseUrl: 'https://api.openai.com/v1',
        );

      case AiProvider.deepseekV3:
      case AiProvider.deepseekR1:
        return OpenAiCompatibleService(
          apiKey: apiKey,
          modelId: provider.modelId,
          baseUrl: 'https://api.deepseek.com',
        );

      case AiProvider.claude35Sonnet:
        return ClaudeService(apiKey: apiKey, modelId: provider.modelId);

      case AiProvider.customOpenAiCompatible:
        final baseUrl = await storage.read(SecureKeys.customAiBaseUrl);
        if (baseUrl == null || baseUrl.isEmpty) {
          throw StateError('Custom AI base URL is not set in Settings.');
        }
        return OpenAiCompatibleService(
          apiKey: apiKey,
          modelId: provider.modelId, // user can override via a custom "model name" field in UI
          baseUrl: baseUrl,
          // Local Ollama and some gateways don't support response_format json_object.
          supportsJsonMode: false,
        );
    }
  }
}
