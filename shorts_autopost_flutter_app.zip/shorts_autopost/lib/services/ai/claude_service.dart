import 'dart:convert';
import 'package:http/http.dart' as http;
import 'ai_provider.dart';

/// Anthropic's Messages API uses a different header scheme (x-api-key +
/// anthropic-version) and response shape than the OpenAI-style providers,
/// so it gets its own implementation rather than reusing OpenAiCompatibleService.
class ClaudeService implements AiProviderService {
  final String apiKey;
  final String modelId; // claude-3-5-sonnet-latest

  ClaudeService({required this.apiKey, required this.modelId});

  static final _endpoint = Uri.parse('https://api.anthropic.com/v1/messages');
  static const _apiVersion = '2023-06-01';

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': _apiVersion,
      };

  @override
  Future<AiGeneratedMetadata> generateMetadata({
    required String videoContextDescription,
    String? niche,
  }) async {
    final prompt = buildMetadataPrompt(videoContext: videoContextDescription, niche: niche);
    final resp = await http.post(
      _endpoint,
      headers: _headers,
      body: jsonEncode({
        'model': modelId,
        'max_tokens': 1024,
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
      }),
    );
    if (resp.statusCode != 200) {
      throw Exception('Claude API error ${resp.statusCode}: ${resp.body}');
    }
    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final text = (data['content'] as List).map((b) => b['text'] ?? '').join();
    return parseModelJson(text);
  }

  @override
  Future<bool> testConnection() async {
    final resp = await http.post(
      _endpoint,
      headers: _headers,
      body: jsonEncode({
        'model': modelId,
        'max_tokens': 5,
        'messages': [
          {'role': 'user', 'content': 'Reply OK'}
        ],
      }),
    );
    return resp.statusCode == 200;
  }
}
