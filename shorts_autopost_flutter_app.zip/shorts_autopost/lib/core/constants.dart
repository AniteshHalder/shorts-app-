/// Global enums & constants shared across the app.

/// Supported BYOK AI providers. Add new ones here + in AiServiceFactory.
enum AiProvider {
  geminiFlash('Google Gemini 1.5 Flash', 'gemini-1.5-flash'),
  geminiPro('Google Gemini 1.5 Pro', 'gemini-1.5-pro'),
  gpt4o('OpenAI GPT-4o', 'gpt-4o'),
  gpt4oMini('OpenAI GPT-4o-mini', 'gpt-4o-mini'),
  deepseekV3('DeepSeek-V3', 'deepseek-chat'),
  deepseekR1('DeepSeek-R1', 'deepseek-reasoner'),
  claude35Sonnet('Anthropic Claude 3.5 Sonnet', 'claude-3-5-sonnet-latest'),
  customOpenAiCompatible('Custom OpenAI-Compatible (Groq/Mistral/Ollama)', 'custom');

  final String displayName;
  final String modelId;
  const AiProvider(this.displayName, this.modelId);
}

/// Row lifecycle inside the local upload queue.
enum QueueStatus { pending, processing, completed, failed }

extension QueueStatusX on QueueStatus {
  String get dbValue => name.toUpperCase(); // PENDING / PROCESSING / ...
  static QueueStatus fromDb(String value) =>
      QueueStatus.values.firstWhere((s) => s.dbValue == value.toUpperCase());
}

/// Target social destinations for a single queue item.
enum SocialPlatform { youtube, instagram, facebook }

/// Secure-storage key names (all values are AES-encrypted at rest by the plugin).
class SecureKeys {
  // AI provider keys
  static const geminiApiKey = 'ai_gemini_api_key';
  static const openAiApiKey = 'ai_openai_api_key';
  static const deepseekApiKey = 'ai_deepseek_api_key';
  static const claudeApiKey = 'ai_claude_api_key';
  static const customAiBaseUrl = 'ai_custom_base_url';
  static const customAiApiKey = 'ai_custom_api_key';
  static const selectedAiProvider = 'ai_selected_provider';

  // Social API credentials
  static const youtubeOAuthClientId = 'yt_oauth_client_id';
  static const youtubeOAuthClientSecret = 'yt_oauth_client_secret';
  static const youtubeAccessToken = 'yt_access_token';
  static const youtubeRefreshToken = 'yt_refresh_token';

  static const metaPageAccessToken = 'meta_page_access_token';
  static const metaPageId = 'meta_page_id';
  static const metaIgBusinessAccountId = 'meta_ig_business_account_id';

  // Google Drive folder-watch
  static const driveWatchFolderId = 'drive_watch_folder_id';

  // Scheduler
  static const burstIntervalMinutes = 'scheduler_burst_interval_minutes';
  static const schedulerEnabled = 'scheduler_enabled';
}

const kMaxYoutubeTitleChars = 60;
const kIgHashtagCount = 15; // 5 viral + 5 niche + 5 micro
const kFbTagCount = 5;
